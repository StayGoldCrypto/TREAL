import { Landing } from "./Landing";

export { Landing };
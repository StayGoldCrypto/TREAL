"use client"

import React, { useState, useEffect } from 'react'
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
//import { ArrowUpRight, Wallet, BarChart2, PieChart, Activity } from 'lucide-react'
import { Wallet, BarChart2, PieChart, Activity } from 'lucide-react'
import { GearApi, GearKeyring, ProgramMetadata } from '@gear-js/api'
import { web3Accounts, web3Enable } from '@polkadot/extension-dapp'
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"

// @@@ Importing section (not clear yet)
//import { ExtendedVFT } from './extended-vft'
// @@@ End Importing section (not clear yet)

  // @@@ gear-js std functions or definitions
    // https://github.com/gear-tech/gear-js/blob/main/api/README.md

    // @@@@ KEYRING
      //const keyring = await GearKeyring.fromSuri('//Alice');
      //console.log(`keyring: ${keyring}`);


// Compiled VFT Program ID on Vara Test Network
const PROGRAM_ID = '0x6b0677f51252b61159542c256b826e50a9982aad15c503ca6b101c9741045963'

    // @@@@ Contract (VFT Extended Program)
        // already defined
        // import { ProgramMetadata } from '@gear-js/api';
          //const meta = ProgramMetadata.from(`0x...`);
//* https://github.com/gear-tech/gear-js/blob/main/api/src/metadata/programMetadata.ts
// @@@Ups...@@@ Document content and github library ts definition does not match params --> constructor(metadata: Uint8Array, lang: number, version: number)
//*        const metax = ProgramMetadata.from(`${PROGRAM_ID}`);
//*        metax.types.init.input; // can be used to encode input message for init entrypoint of the program
//*        metax.types.init.output; // can be used to decode output message for init entrypoint of the program
        // the same thing available for all entrypoints of the program
//*        metax.types.state; // contains type for decoding state output

  // @@@ gear-js std functions or definitions





// Debug Var for Debug Alert
const display_var = 'Insert Consts or Variables'

// Network Connect Function
async function connect() {

  const gearApi = await GearApi.create({
    providerAddress: 'wss://testnet.vara.network',
  });

  const [chain, nodeName, nodeVersion] = await Promise.all([
    gearApi.chain(),
    gearApi.nodeName(),
    gearApi.nodeVersion(),
  ]);


  //const meta = ProgramMetadata.from(PROGRAM_ID);
  //const programId = PROGRAM_ID;
  //const programExists = await api.program.exists(programId);

  //console.log(`Program with address ${programId} ${programExists ? 'exists' : "doesn't exist"}`);

  //console.log(`Program with address: ${meta}`);
  // ${programExists ? 'exists' : "doesn't exist"}


  console.log(
    `Connected to chain ${chain} using ${nodeName} v${nodeVersion}`,
  );

  const unsub = await gearApi.gearEvents.subscribeToNewBlocks((header) => {
    console.log(
      `New block with number: ${header.number.toNumber()} and hash: ${header.hash.toHex()}`,
    );
  });
}
connect().catch(console.error);

// Wallet Connect Function
async function connectwall() {
  // vars ${gjsAccount} Name ${gjsAccName} balance ${gjsAccBalance}`
  console.log(
    // `Connected to wallet ${gjsAccount} Name ${gjsAccName} balance ${gjsAccBalance}`,
  );
}
connectwall().catch(console.error);


interface TokenData {
  name: string
  symbol: string
  price: number
  marketCap: number
  totalSupply: number
  circulatingSupply: number
}

const dummyTokenData: TokenData = {
  name: "TREAL",
  symbol: "TREAL",
  price: 1.06,
  marketCap: 1060000000,
  totalSupply: 1000000000,
  circulatingSupply: 75000000,
}

// Replace with your actual program ID
//const PROGRAM_ID = '0x0000000000000000000000000000000000000000000000000000000000000000'


export function TokenInfoComponent() {

/*
 *  const [isConnected, setIsConnected] = useState(false)
 *  const [tokenData, setTokenData] = useState<TokenData>(dummyTokenData)
  const [walletAddress, setWalletAddress] = useState<string | null>(null)
  const [gearApi, setGearApi] = useState<GearApi | null>(null)
  const [amount, setAmount] = useState("")
  const [recipient, setRecipient] = useState("")
  const [balance, setBalance] = useState("0")
  const [error, setError] = useState<string | null>(null)
  const [success, setSuccess] = useState<string | null>(null)

  useEffect(() => {
    const initializeGearApi = async () => {
      try {
        const api = await GearApi.create({ providerAddress: 'wss://rpc-node.vara-network.io' })
        setGearApi(api)
      } catch (error) {
        console.error('Failed to initialize Gear API:', error)
        setError('Failed to initialize Gear API. Please try again.')
      }
    }

    initializeGearApi()
/*
    if (typeof window !== "undefined") {
      // Este código solo se ejecutará en el navegador
      console.log(window.location.href);
    }
    */
/*
  }, [])
*/

/*
  const connectWallet = async () => {
    if (!gearApi) {
      setError('Gear API not initialized. Please wait and try again.')
      return
    }

    try {
      const extensions = await web3Enable('TREAL Token App')
      if (extensions.length === 0) {
        setError('No extension found. Please install Polkadot.js extension and try again.')
        return
      }

      const allAccounts = await web3Accounts()
      if (allAccounts.length === 0) {
        setError('No accounts found. Please create an account in Polkadot.js extension and try again.')
        return
      }


      const account = allAccounts[0]
      setWalletAddress(account.address)
      setIsConnected(true)
      setSuccess('Wallet connected successfully!')
      await updateBalance(account.address)
    } catch (error) {
      console.error('Error connecting to wallet:', error)
      setError('Failed to connect wallet. Please try again.')
    }
  }



  const disconnectWallet = () => {
    setWalletAddress(null)
    setIsConnected(false)
    setBalance("0")
    setSuccess('Wallet disconnected successfully!')
  }

  const handleConnect = () => {
    if (isConnected) {
      disconnectWallet()
    } else {
      connectWallet()
    }
  }
/*
  const updateBalance = async (address: string) => {
    if (!gearApi) return


    try {
//      const contract = programId
 //     const balance = await contract.balanceOf(address)
      setBalance("101010")
      //balance.toString()
    } catch (error) {
      console.error('Error updating balance:', error)
      setError('Failed to update balance. Please try again.')
    }
  }

  const handleTransfer = async () => {
    if (!gearApi || !walletAddress) {
      setError('Please connect your wallet first.')
      return
    }


    try {
    //  const contract = new ExtendedVFT(gearApi, PROGRAM_ID)
    //  await contract.transfer(recipient, amount)
      setSuccess('Transfer successful!')
      // await updateBalance(walletAddress)
      updateBalance("3030303")
    } catch (error) {
      console.error('Transfer failed:', error)
      setError('Transfer failed. Please check your inputs and try again.')
    }
  }

  const handleStake = async () => {
    if (!gearApi || !walletAddress) {
      setError('Please connect your wallet first.')
      return
    }

    try {
      // const contract = new ExtendedVFT(gearApi, PROGRAM_ID)
      //await contract.stake(amount)
      setSuccess('Stake successful!')
      updateBalance("20202020")
      //await updateBalance(walletAddress)
    } catch (error) {
      console.error('Stake failed:', error)
      setError('Stake failed. Please check your input and try again.')
    }


  }

const handleUnstake = async () => {
    if (!gearApi || !walletAddress) {
      setError('Please connect your wallet first.')
      return
    }


    try {
      //const contract = new ExtendedVFT(gearApi, PROGRAM_ID)
      //await contract.unstake(amount)
      setSuccess('Unstake successful!')
      //await updateBalance(walletAddress)
      updateBalance("4040404")
    } catch (error) {
      console.error('Unstake failed:', error)
      setError('Unstake failed. Please check your input and try again.')
    }

  }
*/
// Temp Vars
const debug_vars = true
const display_value = {display_var}
const success = true
const display_error = false
const isConnected = false
const handleConnect = () => {
}
const [tokenData, setTokenData] = useState<TokenData>(dummyTokenData)

 const [gearApi, setGearApi] = useState<GearApi | null>(null)
 const [walletAddress, setWalletAddress] = useState<string | null>(null)
 const [amount, setAmount] = useState("")
 const [recipient, setRecipient] = useState("")
 const [error, setError] = useState<string | null>(null)

 const handleTransfer = async () => {
     if (!gearApi || !walletAddress) {
       setError('Please connect your wallet first.')
       return
     }
 }

 const handleStake = async () => {
     if (!gearApi || !walletAddress) {
       setError('Please connect your wallet first.')
       return
     }
 }

 const handleUnstake = async () => {
     if (!gearApi || !walletAddress) {
       setError('Please connect your wallet first.')
       return
     }
 }

// Temp Vars

  return (
    <div className="min-h-screen bg-gradient-to-br from-black via-gray-900 to-green-900 text-white p-8">
      <div className="max-w-6xl mx-auto">

      <header className="flex justify-between items-center mb-8">
      <h1 className="text-3xl font-bold text-green-400">{dummyTokenData.name} on Vara Network</h1>
      <Button
      onClick={handleConnect} //{handleConnect}
      variant="outline"
      className="bg-gradient-to-r from-green-500 to-green-700 hover:from-green-600 hover:to-green-800 text-white border-green-600"
      >
      <Wallet className="mr-2 h-4 w-4" />
      {isConnected ? "Disconnect Wallet" : "Connect Wallet"}
      </Button>
      </header>

      {display_error && (
        <Alert variant="destructive" className="mb-4">
        <AlertTitle>Error</AlertTitle>
        <AlertDescription>{display_error}</AlertDescription>
        </Alert>
      )}

      {success && (
        <Alert className="mb-4 bg-green-900 border-green-400 text-green-400">
        <AlertTitle>Success</AlertTitle>
        <AlertDescription>{success}</AlertDescription>
        </Alert>
      )}

      {debug_vars && (
        <Alert className="mb-4 bg-white-900 border-gray-400 text-green-400">
        <AlertTitle>Debug Vars or Consts </AlertTitle>
        <AlertDescription>{success}</AlertDescription>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        <p>value: (put var or consts)</p>
        </div>
        </Alert>
      )}


      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        <Card className="bg-gradient-to-br from-green-900 to-black border-green-700">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
          <CardTitle className="text-sm font-medium text-green-400">Token Price</CardTitle>
          <BarChart2 className="h-4 w-4 text-green-400" />
          </CardHeader>
          <CardContent>
          <div className="text-2xl font-bold text-green-400">USD${tokenData.price.toFixed(2)}</div>
          <p className="text-xs text-green-600">
          +6.0% from yesterday
          </p>
          </CardContent>
        </Card>
        <Card className="bg-gradient-to-br from-green-900 to-black border-green-700">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
          <CardTitle className="text-sm font-medium text-green-400">Market Cap</CardTitle>
          <PieChart className="h-4 w-4 text-green-400" />
          </CardHeader>
          <CardContent>
          <div className="text-2xl font-bold text-green-400">${tokenData.marketCap.toLocaleString()}</div>
          <p className="text-xs text-green-600">
          +2.5% from last week
          </p>
          </CardContent>
        </Card>
        <Card className="bg-gradient-to-br from-green-900 to-black border-green-700">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
          <CardTitle className="text-sm font-medium text-green-400">Circulating Supply</CardTitle>
          <Activity className="h-4 w-4 text-green-400" />
          </CardHeader>
          <CardContent>
          <div className="text-2xl font-bold text-green-400">{tokenData.circulatingSupply.toLocaleString()} {tokenData.symbol}</div>
          <p className="text-xs text-green-600">
          {((tokenData.circulatingSupply / tokenData.totalSupply) * 100).toFixed(2)}% of total supply
          </p>
          </CardContent>
        </Card>
      </div>


 <Tabs defaultValue="transfer" className="w-full">

    <TabsList className="grid w-full grid-cols-3 bg-gradient-to-r from-green-900 to-black">
      <TabsTrigger value="transfer" className="data-[state=active]:bg-green-700 data-[state=active]:text-white">Transfer</TabsTrigger>
      <TabsTrigger value="stake" className="data-[state=active]:bg-green-700 data-[state=active]:text-white">Stake</TabsTrigger>
      <TabsTrigger value="unstake" className="data-[state=active]:bg-green-700 data-[state=active]:text-white">Unstake</TabsTrigger>
    </TabsList>

    <TabsContent value="transfer">
      <Card className="bg-gradient-to-br from-green-900 to-black border-green-700">
      <CardHeader>
      <CardTitle className="text-green-400">Transfer {tokenData.symbol}</CardTitle>
      </CardHeader>
      <CardContent className="space-y-2">
      <div className="space-y-1">
      <Label htmlFor="address" className="text-green-400">Recipient Address</Label>
      <Input
      id="address"
      placeholder="Enter recipient address"
      className="bg-black border-green-700 text-green-400 placeholder-green-700"
      value={recipient}
      onChange={(e) => setRecipient(e.target.value)}
      />
      </div>
      <div className="space-y-1">
      <Label htmlFor="amount" className="text-green-400">Amount</Label>
      <Input
      id="amount"
      placeholder="Enter amount"
      value={amount}
      onChange={(e) => setAmount(e.target.value)}
      className="bg-black border-green-700 text-green-400 placeholder-green-700"
      />
      </div>
      <Button className="w-full bg-gradient-to-r from-green-500 to-green-700 hover:from-green-600 hover:to-green-800 text-white" onClick={handleTransfer}>Transfer</Button>
      </CardContent>
      </Card>
    </TabsContent>

    <TabsContent value="stake">
      <Card className="bg-gradient-to-br from-green-900 to-black border-green-700">
      <CardHeader>
      <CardTitle className="text-green-400">Stake {tokenData.symbol}</CardTitle>
      </CardHeader>
      <CardContent className="space-y-2">
      <div className="space-y-1">
      <Label htmlFor="stake-amount" className="text-green-400">Amount to Stake</Label>
      <Input
      id="stake-amount"
      placeholder="Enter amount to stake"
      className="bg-black border-green-700 text-green-400 placeholder-green-700"
      value={amount}
      onChange={(e) => setAmount(e.target.value)}
      />
      </div>
      <Button className="w-full bg-gradient-to-r from-green-500 to-green-700 hover:from-green-600 hover:to-green-800 text-white" onClick={handleStake}>Stake</Button>
      </CardContent>
      </Card>
    </TabsContent>

    <TabsContent value="unstake">
      <Card className="bg-gradient-to-br from-green-900 to-black border-green-700">
      <CardHeader>
      <CardTitle className="text-green-400">Unstake {tokenData.symbol}</CardTitle>
      </CardHeader>
      <CardContent className="space-y-2">
      <div className="space-y-1">
      <Label htmlFor="unstake-amount" className="text-green-400">Amount to Unstake</Label>
      <Input
      id="unstake-amount"
      placeholder="Enter amount to unstake"
      className="bg-black border-green-700 text-green-400 placeholder-green-700"
      value={amount}
      onChange={(e) => setAmount(e.target.value)}
      />
      </div>
      <Button className="w-full bg-gradient-to-r from-green-500 to-green-700 hover:from-green-600 hover:to-green-800 text-white" onClick={handleUnstake}>Unstake</Button>
      </CardContent>
      </Card>
    </TabsContent>
 </Tabs>

      </div>
    </div>
  )
}

/*
 *  swap coding



 <Tabs defaultValue="transfer" className="w-full">

    <TabsList className="grid w-full grid-cols-3 bg-gradient-to-r from-green-900 to-black">
      <TabsTrigger value="transfer" className="data-[state=active]:bg-green-700 data-[state=active]:text-white">Transfer</TabsTrigger>
      <TabsTrigger value="stake" className="data-[state=active]:bg-green-700 data-[state=active]:text-white">Stake</TabsTrigger>
      <TabsTrigger value="unstake" className="data-[state=active]:bg-green-700 data-[state=active]:text-white">Unstake</TabsTrigger>
    </TabsList>

    <TabsContent value="transfer">
      <Card className="bg-gradient-to-br from-green-900 to-black border-green-700">
      <CardHeader>
      <CardTitle className="text-green-400">Transfer {tokenData.symbol}</CardTitle>
      </CardHeader>
      <CardContent className="space-y-2">
      <div className="space-y-1">
      <Label htmlFor="address" className="text-green-400">Recipient Address</Label>
      <Input
      id="address"
      placeholder="Enter recipient address"
      className="bg-black border-green-700 text-green-400 placeholder-green-700"
      value={recipient}
      onChange={(e) => setRecipient(e.target.value)}
      />
      </div>
      <div className="space-y-1">
      <Label htmlFor="amount" className="text-green-400">Amount</Label>
      <Input
      id="amount"
      placeholder="Enter amount"
      value={amount}
      onChange={(e) => setAmount(e.target.value)}
      className="bg-black border-green-700 text-green-400 placeholder-green-700"
      />
      </div>
      <Button className="w-full bg-gradient-to-r from-green-500 to-green-700 hover:from-green-600 hover:to-green-800 text-white" onClick={handleTransfer}>Transfer</Button>
      </CardContent>
      </Card>
    </TabsContent>

    <TabsContent value="stake">
      <Card className="bg-gradient-to-br from-green-900 to-black border-green-700">
      <CardHeader>
      <CardTitle className="text-green-400">Stake {tokenData.symbol}</CardTitle>
      </CardHeader>
      <CardContent className="space-y-2">
      <div className="space-y-1">
      <Label htmlFor="stake-amount" className="text-green-400">Amount to Stake</Label>
      <Input
      id="stake-amount"
      placeholder="Enter amount to stake"
      className="bg-black border-green-700 text-green-400 placeholder-green-700"
      value={amount}
      onChange={(e) => setAmount(e.target.value)}
      />
      </div>
      <Button className="w-full bg-gradient-to-r from-green-500 to-green-700 hover:from-green-600 hover:to-green-800 text-white" onClick={handleStake}>Stake</Button>
      </CardContent>
      </Card>
    </TabsContent>

    <TabsContent value="unstake">
      <Card className="bg-gradient-to-br from-green-900 to-black border-green-700">
      <CardHeader>
      <CardTitle className="text-green-400">Unstake {tokenData.symbol}</CardTitle>
      </CardHeader>
      <CardContent className="space-y-2">
      <div className="space-y-1">
      <Label htmlFor="unstake-amount" className="text-green-400">Amount to Unstake</Label>
      <Input
      id="unstake-amount"
      placeholder="Enter amount to unstake"
      className="bg-black border-green-700 text-green-400 placeholder-green-700"
      value={amount}
      onChange={(e) => setAmount(e.target.value)}
      />
      </div>
      <Button className="w-full bg-gradient-to-r from-green-500 to-green-700 hover:from-green-600 hover:to-green-800 text-white" onClick={handleUnstake}>Unstake</Button>
      </CardContent>
      </Card>
    </TabsContent>
 </Tabs>

 *
 *  end swap coding
 *

 // {display_value}

 <div className="min-h-screen bg-gradient-to-br from-black via-gray-900 to-green-900 text-white p-8">
      <div className="max-w-6xl mx-auto">

      </div>
    </div>


        <header className="flex justify-between items-center mb-8">
          <h1 className="text-3xl font-bold text-green-400">{tokenData.name} on Vara Network</h1>
          <Button
            onClick={handleConnect}
            variant="outline"
            className="bg-gradient-to-r from-green-500 to-green-700 hover:from-green-600 hover:to-green-800 text-white border-green-600"
          >
            <Wallet className="mr-2 h-4 w-4" />
            {isConnected ? "Disconnect Wallet" : "Connect Wallet"}
          </Button>
        </header>

 {error && (
   <Alert variant="destructive" className="mb-4">
   <AlertTitle>Error</AlertTitle>
   <AlertDescription>{error}</AlertDescription>
   </Alert>
   )}

   {success && (
     <Alert className="mb-4 bg-green-900 border-green-400 text-green-400">
     <AlertTitle>Success</AlertTitle>
     <AlertDescription>{success}</AlertDescription>
     </Alert>
     )}

     {isConnected && walletAddress && (
       <div className="mb-4 p-4 bg-gradient-to-r from-green-900 to-black rounded-lg border border-green-700">
       <p className="text-sm text-green-400">Connected Wallet: {walletAddress}</p>
       <p className="text-sm text-green-400">Balance: {balance} {tokenData.symbol}</p>
       </div>
       )}

       <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
       <Card className="bg-gradient-to-br from-green-900 to-black border-green-700">
       <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
       <CardTitle className="text-sm font-medium text-green-400">Token Price</CardTitle>
       <BarChart2 className="h-4 w-4 text-green-400" />
       </CardHeader>
       <CardContent>
       <div className="text-2xl font-bold text-green-400">${tokenData.price.toFixed(2)}</div>
       <p className="text-xs text-green-600">
       +0.1% from yesterday
       </p>
       </CardContent>
       </Card>
       <Card className="bg-gradient-to-br from-green-900 to-black border-green-700">
       <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
       <CardTitle className="text-sm font-medium text-green-400">Market Cap</CardTitle>
       <PieChart className="h-4 w-4 text-green-400" />
       </CardHeader>
       <CardContent>
       <div className="text-2xl font-bold text-green-400">${tokenData.marketCap.toLocaleString()}</div>
       <p className="text-xs text-green-600">
       +2.5% from last week
       </p>
       </CardContent>
       </Card>
       <Card className="bg-gradient-to-br from-green-900 to-black border-green-700">
       <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
       <CardTitle className="text-sm font-medium text-green-400">Circulating Supply</CardTitle>
       <Activity className="h-4 w-4 text-green-400" />
       </CardHeader>
       <CardContent>
       <div className="text-2xl font-bold text-green-400">{tokenData.circulatingSupply.toLocaleString()} {tokenData.symbol}</div>
       <p className="text-xs text-green-600">
       {((tokenData.circulatingSupply / tokenData.totalSupply) * 100).toFixed(2)}% of total supply
       </p>
       </CardContent>
       </Card>
       </div>

       <Tabs defaultValue="transfer" className="w-full">
       <TabsList className="grid w-full grid-cols-3 bg-gradient-to-r from-green-900 to-black">
       <TabsTrigger value="transfer" className="data-[state=active]:bg-green-700 data-[state=active]:text-white">Transfer</TabsTrigger>
       <TabsTrigger value="stake" className="data-[state=active]:bg-green-700 data-[state=active]:text-white">Stake</TabsTrigger>
       <TabsTrigger value="unstake" className="data-[state=active]:bg-green-700 data-[state=active]:text-white">Unstake</TabsTrigger>
       </TabsList>
       <TabsContent value="transfer">
       <Card className="bg-gradient-to-br from-green-900 to-black border-green-700">
       <CardHeader>
       <CardTitle className="text-green-400">Transfer {tokenData.symbol}</CardTitle>
       </CardHeader>
       <CardContent className="space-y-2">
       <div className="space-y-1">
       <Label htmlFor="address" className="text-green-400">Recipient Address</Label>
       <Input
       id="address"
       placeholder="Enter recipient address"
       className="bg-black border-green-700 text-green-400 placeholder-green-700"
       value={recipient}
       onChange={(e) => setRecipient(e.target.value)}
       />
       </div>
       <div className="space-y-1">
       <Label htmlFor="amount" className="text-green-400">Amount</Label>
       <Input
       id="amount"
       placeholder="Enter amount"
       value={amount}
       onChange={(e) => setAmount(e.target.value)}
       className="bg-black border-green-700 text-green-400 placeholder-green-700"
       />
       </div>
       <Button className="w-full bg-gradient-to-r from-green-500 to-green-700 hover:from-green-600 hover:to-green-800 text-white" onClick={handleTransfer}>Transfer</Button>
       </CardContent>
       </Card>
       </TabsContent>
       <TabsContent value="stake">
       <Card className="bg-gradient-to-br from-green-900 to-black border-green-700">
       <CardHeader>
       <CardTitle className="text-green-400">Stake {tokenData.symbol}</CardTitle>
       </CardHeader>
       <CardContent className="space-y-2">
       <div className="space-y-1">
       <Label htmlFor="stake-amount" className="text-green-400">Amount to Stake</Label>
       <Input
       id="stake-amount"
       placeholder="Enter amount to stake"
       className="bg-black border-green-700 text-green-400 placeholder-green-700"
       value={amount}
       onChange={(e) => setAmount(e.target.value)}
       />
       </div>
       <Button className="w-full bg-gradient-to-r from-green-500 to-green-700 hover:from-green-600 hover:to-green-800 text-white" onClick={handleStake}>Stake</Button>
       </CardContent>
       </Card>
       </TabsContent>
       <TabsContent value="unstake">
       <Card className="bg-gradient-to-br from-green-900 to-black border-green-700">
       <CardHeader>
       <CardTitle className="text-green-400">Unstake {tokenData.symbol}</CardTitle>
       </CardHeader>
       <CardContent className="space-y-2">
       <div className="space-y-1">
       <Label htmlFor="unstake-amount" className="text-green-400">Amount to Unstake</Label>
       <Input
       id="unstake-amount"
       placeholder="Enter amount to unstake"
       className="bg-black border-green-700 text-green-400 placeholder-green-700"
       value={amount}
       onChange={(e) => setAmount(e.target.value)}
       />
       </div>
       <Button className="w-full bg-gradient-to-r from-green-500 to-green-700 hover:from-green-600 hover:to-green-800 text-white" onClick={handleUnstake}>Unstake</Button>
       </CardContent>
       </Card>
       </TabsContent>
       </Tabs>

 */

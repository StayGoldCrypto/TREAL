export { Text, textVariants } from './text';
export type { TextProps } from './text';

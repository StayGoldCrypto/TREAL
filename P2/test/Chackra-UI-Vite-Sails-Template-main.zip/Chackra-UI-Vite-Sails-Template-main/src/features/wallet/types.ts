import { WALLET } from './consts';

type WalletId = keyof typeof WALLET;

export type { WalletId };

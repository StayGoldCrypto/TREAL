import { TextGradient } from './text-gradient';

export { TextGradient };

import { TokenInfoComponent } from "@/components/token-info"

export default function Page() {
  return <TokenInfoComponent />
}

module.exports = {
  extends: ['next', 'next/core-web-vitals'], // Agrega estas reglas de Next.js
  rules: {
    '@typescript-eslint/no-unused-vars': 'off', // Desactiva el error de variables no usadas
    '@typescript-eslint/no-empty-interface': 'off' // Desactiva el error de interfaces vacías
  }
  };

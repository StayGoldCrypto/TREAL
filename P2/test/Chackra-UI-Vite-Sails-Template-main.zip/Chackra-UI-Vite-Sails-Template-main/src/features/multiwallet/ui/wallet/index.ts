import { MultiWallet } from './wallet';

export { MultiWallet };
